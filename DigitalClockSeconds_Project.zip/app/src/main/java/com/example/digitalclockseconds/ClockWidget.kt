package com.example.digitalclockseconds
import android.appwidget.*
import android.content.Context
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*
class ClockWidget: AppWidgetProvider(){
 override fun onUpdate(c:Context,m:AppWidgetManager,ids:IntArray){
  val t=SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(Date())
  val d=SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(Date())
  ids.forEach{ id-> RemoteViews(c.packageName,R.layout.widget_clock).apply{setTextViewText(R.id.time,t);setTextViewText(R.id.date,d);m.updateAppWidget(id,this)}}
 }
}
