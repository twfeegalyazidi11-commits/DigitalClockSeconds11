package com.example.digitalclockseconds
import android.app.Activity
import android.os.Bundle
import android.widget.TextView
class MainActivity: Activity(){ override fun onCreate(b:Bundle?){super.onCreate(b); setContentView(TextView(this).apply{ text="Digital Clock Seconds\n\nأضف الودجت من الشاشة الرئيسية."; textSize=18f; setPadding(32,48,32,48) })}}
